/*
 * Copyright 2003-2013 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package pid

class External {

    def internal = new Internal()

}

class Internal {

    def map = [:]

    def register(String address, Closure c) {
        println "register: $address"
        this.map[address] = c
    }

    def unregister(String address, Closure c) {
        println "unregister: $address"
        map.remove(address)
    }

    def send(String address, String data) {
        map[address]?.call(data)
    }

}

class Wrapper {

    def external = new External()

    def start() {
    }

    def stop() {
    }

    @Handler('test')
    def receiver(Object input) {
        println "input: $input"
    }

}


def w = new Wrapper()
w.start()

w.external.internal.send('test', 'foo')

w.stop()

println "fin!"