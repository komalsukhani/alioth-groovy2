/*
 * Copyright 2003-2013 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package pid

import org.codehaus.groovy.ast.ASTNode
import org.codehaus.groovy.ast.AnnotationNode
import org.codehaus.groovy.ast.MethodNode
import org.codehaus.groovy.ast.expr.ArgumentListExpression
import org.codehaus.groovy.ast.expr.ConstantExpression
import org.codehaus.groovy.ast.expr.MethodCallExpression
import org.codehaus.groovy.ast.expr.MethodPointerExpression
import org.codehaus.groovy.ast.expr.PropertyExpression
import org.codehaus.groovy.ast.expr.VariableExpression
import org.codehaus.groovy.ast.stmt.BlockStatement
import org.codehaus.groovy.ast.stmt.ExpressionStatement
import org.codehaus.groovy.ast.stmt.Statement
import org.codehaus.groovy.control.CompilePhase
import org.codehaus.groovy.control.SourceUnit
import org.codehaus.groovy.transform.ASTTransformation
import org.codehaus.groovy.transform.GroovyASTTransformation

@GroovyASTTransformation(phase=CompilePhase.SEMANTIC_ANALYSIS)
public class HandlerASTTransformation implements ASTTransformation {

    void visit(ASTNode[] astNodes, SourceUnit source) {

        if (!astNodes) return
        if (!astNodes[0] instanceof AnnotationNode) return
        if (!astNodes[1] instanceof MethodNode) return

        def annotatedNode = astNodes[1]

        String address = astNodes[0].getMember('value').text // derive from Handler annotation value
        String methodName = annotatedNode.name // derive from annotated method

        def cn = annotatedNode.declaringClass
        cn.methods.each { mn ->
            if (mn.name == 'start') {
                doAddStatement(mn, createStatement('register', address, methodName))
            }
            if (mn.name == 'stop') {
                doAddStatement(mn, createStatement('unregister', address, methodName))
            }
        }
    }

    private void doAddStatement(MethodNode mn, Statement stmt) {
        def code = mn.code
        if (code instanceof BlockStatement) {
            code.addStatement(stmt)
        } else {
            BlockStatement block = new BlockStatement()
            block.add(code)
            block.add(stmt)
            mn.code = block
        }
    }

    private Statement createStatement(String event, String address, String methodName) {
        def mce = new MethodCallExpression(
                new PropertyExpression(
                        new PropertyExpression(
                                new VariableExpression('this'),
                                new ConstantExpression('external')
                        ), new ConstantExpression('internal'))
                ,
                event,
                new ArgumentListExpression(
                        new ConstantExpression(address),
                        new MethodPointerExpression(
                                new VariableExpression('this'),
                                new ConstantExpression(methodName)
                        )
                )
        )
        mce.implicitThis = false
        new ExpressionStatement(mce)
    }

}
